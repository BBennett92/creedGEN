
import os

combinations = []

for i in range(1000):
    combination = "creed" + str(i).zfill(3)
    combinations.append(combination)

art = """
#                               _  _____  _____  _   _ 
#                              | ||  __ \|  ___|| \ | |
#    ___  _ __   ___   ___   __| || |  \/| |__  |  \| |
#   / __|| '__| / _ \ / _ \ / _` || | __ |  __| | . ` |
#  | (__ | |   |  __/|  __/| (_| || |_\ \| |___ | |\  |
#   \___||_|    \___| \___| \__,_| \____/\____/ \_| \_/
#                                                      
#                                                      
"""

script_dir = os.path.dirname(os.path.realpath(__file__))
filename = os.path.join(script_dir, "creedPWNlist.txt")

with open(filename, "w") as f:
    for combination in combinations:
        f.write(combination + "\n")

print(art)

input("Hello and welcome to 'creedGEN' the one and ONLY wordlist generator used for cracking Creed's password! Copy The text below or just use the wordlist that will be printed for you in the file you ran this script from! Press enter to continue...")

print("\n".join(combinations))

input()