#                               _  _____  _____  _   _ 
#                              | ||  __ \|  ___|| \ | |
#    ___  _ __   ___   ___   __| || |  \/| |__  |  \| |
#   / __|| '__| / _ \ / _ \ / _` || | __ |  __| | . ` |
#  | (__ | |   |  __/|  __/| (_| || |_\ \| |___ | |\  |
#   \___||_|    \___| \___| \__,_| \____/\____/ \_| \_/
#                                                      
#                                                      



READ ME!






This python script 'creedGEN' will generate a wordlist called
'creedPWNlist.txt'
for the VulnHub box 'The Office: Doomsday Device' needed
to brute force one of the flags and this tool will
come in handy for you! Prints 'creed' with a combination
of 3 numbers as the clue states such as 'creed123, creed456, etc.'
enjoy this if you find it!



-mh
